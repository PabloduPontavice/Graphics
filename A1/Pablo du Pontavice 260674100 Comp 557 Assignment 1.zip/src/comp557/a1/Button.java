package comp557.a1;

public class Button {

}
